import p1_img from './t-shirt(1).jpg';
import p2_img from './t-shirt(2).jpg';
import p3_img from './t-shirt(3).jpg';
import p4_img from './t-shirt(4).jpg';

let data_product = [
  {
    id: 1,
    name: 't-shirt1',
    image: p1_img,
    new_price: 50,
    old_price: 60,
    category: 'men',
  },
  {
    id: 2,
    name: 't-shirt2',
    image: p2_img,
    new_price: 50,
    old_price: 60,
    category: 'men',
  },
  {
    id: 3,
    name: 't-shirt3',
    image: p3_img,
    new_price: 50,
    old_price: 60,
    category: 'woman',
  },
  {
    id: 4,
    name: 't-shirt4',
    image: p4_img,
    new_price: 50,
    old_price: 60,
    category: 'kid',
  },
];

export default data_product;
